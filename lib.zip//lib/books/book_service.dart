import 'book_model.dart';

class BookService {
  List<Book> getBooks() {
    return [
      Book(id: '1', title: 'Atomic Habits'),
      Book(id: '2', title: '1984'),
    ];
  }
}